<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="content-area">
    <div class="page-404">
        <h1>404</h1>
        <p>你访问的页面不存在或已被移除</p>
        <a href="<?php $this->options->siteUrl(); ?>">返回首页</a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
