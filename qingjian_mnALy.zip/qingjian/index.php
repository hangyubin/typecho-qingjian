<?php
/**
 * 清简 (QingJian) — 一款简约纯净的 Typecho 博客主题
 *
 * @package     QingJian
 * @author      MiMo
 * @version     1.5.0
 * @link        https://github.com/xiaomi/mimo
 * @description 纯净 · 融合 · 无卡片 · 自适应宽度 · 支持主题配色切换
 *
 * ==================================================
 *
 * 主题特性：
 *
 * 1. 简约纯净的设计风格，无卡片式布局，内容自然融入背景
 * 2. 侧边栏导航 + 右侧自适应主内容区，支持响应式适配
 * 3. 内置 6 种主题配色方案（暖棕、蓝、绿、紫、橙、红）及自定义配色
 * 4. 内置文章目录 (TOC)，自动提取 h2/h3 标题，支持平滑跳转
 * 5. 阅读进度条、返回顶部、文章浏览量统计
 * 6. 友情链接页面模板，后台可视化管理
 * 7. 支持自定义 Logo、Favicon、头像、副标题、ICP 备案号
 * 8. 支持自定义 CSS / JavaScript / 页脚内容
 * 9. 支持 Gravatar 头像镜像源配置（默认 Cravatar 国内镜像）
 * 10. 未登录用户可浏览文章，登录后方可发表评论
 *
 * ==================================================
 *
 * 作者：MiMo
 * 官方主页：https://github.com/xiaomi/mimo
 * 反馈建议：https://github.com/xiaomi/mimo/issues
 *
 * ==================================================
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<?php $this->need('header.php'); ?>

<div class="content-area">
    <div class="post-list">
        <?php while($this->next()): ?>
        <article class="post-item">
            <h2 class="post-title">
                <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="meta-author"><?php $this->author->screenName(); ?></span>
                <span class="meta-sep">·</span>
                <time><?php $this->date('Y-m-d'); ?></time>
                <span class="meta-sep">·</span>
                <span class="meta-category"><?php $this->category(', '); ?></span>
                <span class="meta-sep">·</span>
                <span class="meta-views"><?php echo formatViews(getViews($this->cid)); ?> 阅读</span>
                <span class="meta-sep">·</span>
                <span><?php $this->commentsNum('0 评论', '1 评论', '%d 评论'); ?></span>
            </div>
            <div class="post-excerpt"><?php $this->excerpt(140, '...'); ?></div>
        </article>
        <?php endwhile; ?>
    </div>

    <?php $this->pageNav('« 上一页', '下一页 »'); ?>
</div>

<?php $this->need('footer.php'); ?>
