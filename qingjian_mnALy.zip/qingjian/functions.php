<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * Typecho-One-Theme
 * @package Typecho-One-Theme
 * @author RAO
 * @version 1.5.0
 */

// ============================================================
//  辅助函数
// ============================================================

function getViews($cid) {
    $db = \Typecho\Db::get();
    try {
        $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid)->limit(1));
        return isset($row['views']) ? $row['views'] : 0;
    } catch (Exception $e) {
        return 0;
    }
}

function formatViews($num) {
    if ($num >= 10000) {
        return round($num / 10000, 1) . '万';
    } elseif ($num >= 1000) {
        return round($num / 1000, 1) . 'k';
    }
    return $num;
}

function getPostThumb($content) {
    preg_match_all('/<img[^>]*src=["\']([^"\']+)["\'][^>]*>/i', $content, $matches);
    if (isset($matches[1][0])) {
        return $matches[1][0];
    }
    return false;
}

function getExcerpt($content, $length = 120) {
    $content = strip_tags($content);
    $content = preg_replace('/\s+/', ' ', $content);
    $content = trim($content);
    if (mb_strlen($content, 'UTF-8') > $length) {
        $content = mb_substr($content, 0, $length, 'UTF-8') . '...';
    }
    return $content;
}

function getLinksData() {
    $options = \Typecho\Widget::widget('Widget_Options');
    $links = array();
    if (!isset($options->enableLinks) || $options->enableLinks != '1') {
        return $links;
    }
    if (isset($options->linksData) && !empty($options->linksData)) {
        $lines = explode("\n", trim($options->linksData));
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            $parts = explode('||', $line);
            if (count($parts) >= 2) {
                $links[] = array(
                    'name' => trim($parts[0]),
                    'url'  => trim($parts[1]),
                    'icon' => isset($parts[2]) ? trim($parts[2]) : '',
                    'desc' => isset($parts[3]) ? trim($parts[3]) : ''
                );
            }
        }
    }
    return $links;
}

// ============================================================
//  主题配色
// ============================================================

function themeColorCss() {
    $options = \Typecho\Widget::widget('Widget_Options');
    $scheme  = isset($options->themeColor) ? $options->themeColor : 'default';
    $custom  = isset($options->customColor) ? trim($options->customColor) : '#c0553d';

    $palettes = array(
        'default' => array(
            'accent' => '#c0553d', 'accent-hover' => '#a3452f',
            'accent-light' => 'rgba(192, 85, 61, 0.07)', 'sidebar-accent' => '#e8a87c',
        ),
        'blue' => array(
            'accent' => '#2563eb', 'accent-hover' => '#1d4ed8',
            'accent-light' => 'rgba(37, 99, 235, 0.07)', 'sidebar-accent' => '#60a5fa',
        ),
        'green' => array(
            'accent' => '#16a34a', 'accent-hover' => '#15803d',
            'accent-light' => 'rgba(22, 163, 74, 0.07)', 'sidebar-accent' => '#4ade80',
        ),
        'purple' => array(
            'accent' => '#7c3aed', 'accent-hover' => '#6d28d9',
            'accent-light' => 'rgba(124, 58, 237, 0.07)', 'sidebar-accent' => '#a78bfa',
        ),
        'orange' => array(
            'accent' => '#ea580c', 'accent-hover' => '#c2410c',
            'accent-light' => 'rgba(234, 88, 12, 0.07)', 'sidebar-accent' => '#fb923c',
        ),
        'red' => array(
            'accent' => '#dc2626', 'accent-hover' => '#b91c1c',
            'accent-light' => 'rgba(220, 38, 38, 0.07)', 'sidebar-accent' => '#f87171',
        ),
    );

    if ($scheme === 'custom' && !empty($custom)) {
        $palette = array(
            'accent' => $custom, 'accent-hover' => $custom,
            'accent-light' => $custom . '11', 'sidebar-accent' => $custom,
        );
    } elseif (isset($palettes[$scheme])) {
        $palette = $palettes[$scheme];
    } else {
        $palette = $palettes['default'];
    }

    echo '<style>:root{'
        . '--accent:'         . $palette['accent']         . ';'
        . '--accent-hover:'   . $palette['accent-hover']   . ';'
        . '--accent-light:'   . $palette['accent-light']   . ';'
        . '--sidebar-accent:' . $palette['sidebar-accent'] . ';'
        . '}</style>' . "\n";
}

// ============================================================
//  资源获取（后台填写 > 主题目录默认文件）
// ============================================================

function getThemeAvatar() {
    $options = \Typecho\Widget::widget('Widget_Options');
    if (isset($options->avatar) && !empty($options->avatar)) {
        return $options->avatar;
    }
    if (file_exists(__DIR__ . '/images/avatar.png')) {
        return $options->themeUrl . '/images/avatar.png';
    }
    return '';
}

function getThemeLogo() {
    $options = \Typecho\Widget::widget('Widget_Options');
    if (isset($options->logo) && !empty($options->logo)) {
        return $options->logo;
    }
    if (file_exists(__DIR__ . '/images/logo.png')) {
        return $options->themeUrl . '/images/logo.png';
    }
    return '';
}

function getThemeFavicon() {
    $options = \Typecho\Widget::widget('Widget_Options');
    if (isset($options->favicon) && !empty($options->favicon)) {
        return $options->favicon;
    }
    if (file_exists(__DIR__ . '/images/favicon.ico')) {
        return $options->themeUrl . '/images/favicon.ico';
    }
    return '';
}

// ============================================================
//  主题配置
// ============================================================

function themeConfig($form) {

    $themeColor = new \Typecho\Widget\Helper\Form\Element\Radio(
        'themeColor',
        array(
            'default' => _t('经典暖棕'), 'blue' => _t('沉稳蓝'),
            'green' => _t('自然绿'), 'purple' => _t('优雅紫'),
            'orange' => _t('活力橙'), 'red' => _t('中国红'),
            'custom' => _t('自定义'),
        ),
        'default', _t('主题配色方案'),
        _t('选择站点整体配色风格')
    );
    $form->addInput($themeColor);

    $customColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'customColor', NULL, '#c0553d',
        _t('自定义主题色'),
        _t('配色方案选择「自定义」时生效，如 #c0553d')
    );
    $form->addInput($customColor);

    $logo = new \Typecho\Widget\Helper\Form\Element\Text(
        'logo', NULL, '',
        _t('站点 Logo 图片地址'),
        _t('留空则自动使用主题 images/logo.png，都没有则显示站点名称文字')
    );
    $form->addInput($logo);

    $subtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'subtitle', NULL, '',
        _t('站点副标题'),
        _t('显示在站点名称下方的描述文字')
    );
    $form->addInput($subtitle);

    $favicon = new \Typecho\Widget\Helper\Form\Element\Text(
        'favicon', NULL, '',
        _t('Favicon 地址'),
        _t('留空则自动使用主题 images/favicon.ico')
    );
    $form->addInput($favicon);

    $avatar = new \Typecho\Widget\Helper\Form\Element\Text(
        'avatar', NULL, '',
        _t('头像图片地址'),
        _t('留空则自动使用主题 images/avatar.png，都没有则显示站名首字')
    );
    $form->addInput($avatar);

    $enableLinks = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLinks',
        array('1' => _t('开启'), '0' => _t('关闭')),
        '0', _t('友情链接功能'),
        _t('开启后可在下方填写友情链接数据')
    );
    $form->addInput($enableLinks);

    $linksData = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'linksData', NULL, '',
        _t('友情链接数据'),
        _t('每行一个，格式：名称||链接||图标||描述')
    );
    $form->addInput($linksData);

    $icp = new \Typecho\Widget\Helper\Form\Element\Text(
        'icp', NULL, '',
        _t('ICP 备案号'),
        _t('如：京ICP备XXXXXXXX号')
    );
    $form->addInput($icp);

    $pageSize = new \Typecho\Widget\Helper\Form\Element\Text(
        'pageSize', NULL, '10',
        _t('每页文章数'),
        _t('默认 10')
    );
    $form->addInput($pageSize);

    $gravatarMirror = new \Typecho\Widget\Helper\Form\Element\Text(
        'gravatarMirror', NULL, 'https://cravatar.cn/avatar/',
        _t('Gravatar 头像镜像源'),
        _t('评论区头像的镜像源地址')
    );
    $form->addInput($gravatarMirror);

    $customCss = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'customCss', NULL, '',
        _t('自定义 CSS'),
        _t('在此填入自定义 CSS 样式代码')
    );
    $form->addInput($customCss);

    $customJs = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'customJs', NULL, '',
        _t('自定义 JavaScript'),
        _t('在此填入自定义 JavaScript 代码')
    );
    $form->addInput($customJs);

    $footerContent = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerContent', NULL, '',
        _t('页脚自定义内容'),
        _t('填入页脚额外显示的内容')
    );
    $form->addInput($footerContent);
}

// ============================================================
//  主题初始化
// ============================================================

function themeInit($archive) {
    $options = \Typecho\Widget::widget('Widget_Options');
    if (isset($options->pageSize) && $options->pageSize) {
        $archive->parameter->pageSize = intval($options->pageSize);
    }
}
