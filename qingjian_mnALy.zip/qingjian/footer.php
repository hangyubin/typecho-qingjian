<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
    </main>
</div>

<button class="back-to-top" id="backToTop" title="返回顶部">↑</button>

<?php if ($this->options->customJs): ?>
<script><?php $this->options->customJs(); ?></script>
<?php endif; ?>

<script>
(function() {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var toggle  = document.getElementById('menuToggle');
    var backTop = document.getElementById('backToTop');
    if (toggle && sidebar && overlay) {
        toggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
            toggle.classList.toggle('active');
        });
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
            toggle.classList.remove('active');
        });
    }
    if (backTop) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 400) backTop.classList.add('visible');
            else backTop.classList.remove('visible');
        });
        backTop.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
    var bar = document.getElementById('progressBar');
    if (bar) {
        window.addEventListener('scroll', function() {
            var h = document.documentElement.scrollHeight - window.innerHeight;
            bar.style.width = h > 0 ? (window.scrollY / h * 100) + '%' : '0%';
        });
    }
})();
</script>

<script>
(function() {
    var content = document.querySelector('.post-content');
    if (!content) return;
    var headings = content.querySelectorAll('h2, h3');
    if (headings.length < 2) return;

    var items = [];
    for (var i = 0; i < headings.length; i++) {
        var h = headings[i];
        if (!h.id) h.id = 'toc-' + i;
        items.push({ id: h.id, text: h.textContent.trim(), level: h.tagName.toLowerCase() });
    }

    var overlay = document.createElement('div');
    overlay.className = 'toc-overlay';
    overlay.id = 'tocOverlay';

    var panel = document.createElement('div');
    panel.className = 'toc-panel';
    panel.id = 'tocPanel';
    var html = '<div class="toc-header"><span class="toc-label">目录</span><button class="toc-close" id="tocClose">&times;</button></div><ul class="toc-list">';
    for (var i = 0; i < items.length; i++) {
        html += '<li class="toc-item toc-' + items[i].level + '"><a href="#' + items[i].id + '">' + items[i].text + '</a></li>';
    }
    html += '</ul>';
    panel.innerHTML = html;

    var toggle = document.createElement('button');
    toggle.className = 'toc-toggle';
    toggle.id = 'tocToggle';
    toggle.title = '文章目录';
    toggle.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="15" y2="12"/><line x1="3" y1="18" x2="18" y2="18"/></svg>';

    document.body.appendChild(overlay);
    document.body.appendChild(panel);
    document.body.appendChild(toggle);

    function openToc()  { panel.classList.add('open'); overlay.classList.add('active'); toggle.classList.add('active'); }
    function closeToc() { panel.classList.remove('open'); overlay.classList.remove('active'); toggle.classList.remove('active'); }

    toggle.addEventListener('click', function() {
        panel.classList.contains('open') ? closeToc() : openToc();
    });
    overlay.addEventListener('click', closeToc);
    document.getElementById('tocClose').addEventListener('click', closeToc);

    var links = panel.querySelectorAll('.toc-list a');
    var headingEls = [];
    for (var i = 0; i < items.length; i++) headingEls.push(document.getElementById(items[i].id));

    function onScroll() {
        if (window.scrollY > 300) toggle.classList.add('visible');
        else { toggle.classList.remove('visible'); closeToc(); }
        var top = window.scrollY + 120, idx = 0;
        for (var i = headingEls.length - 1; i >= 0; i--) {
            if (headingEls[i].offsetTop <= top) { idx = i; break; }
        }
        for (var i = 0; i < links.length; i++) {
            links[i].parentElement.classList.toggle('active', i === idx);
        }
    }
    window.addEventListener('scroll', onScroll);
    onScroll();

    for (var i = 0; i < links.length; i++) {
        links[i].addEventListener('click', function(e) {
            e.preventDefault();
            var t = document.getElementById(this.getAttribute('href').substring(1));
            if (t) {
                window.scrollTo({ top: t.offsetTop - 80, behavior: 'smooth' });
                if (window.innerWidth <= 1024) closeToc();
            }
        });
    }
})();
</script>

<?php $this->footer(); ?>
</body>
</html>
