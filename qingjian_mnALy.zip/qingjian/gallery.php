<?php
/**
 * 映画集 - 优雅的两级目录瀑布流相册
 *
 * @package custom
 * @author  MiMo
 * @version 1.1.0
 */

// 获取插件配置
$pluginConfig = [];
if (class_exists('YinghuaGallery_Plugin')) {
    $pluginConfig = YinghuaGallery_Plugin::getConfig();
}

$defaultConfig = [
    'scanDir' => '/usr/uploads/album/',
    'perPage' => 30,
    'themeColorValue' => '#007bff'
];

$config = [
    'scanDir' => isset($pluginConfig['scanDir']) ? $pluginConfig['scanDir'] : $defaultConfig['scanDir'],
    'perPage' => isset($pluginConfig['perPage']) ? intval($pluginConfig['perPage']) : $defaultConfig['perPage'],
    'themeColor' => isset($pluginConfig['themeColorValue']) ? $pluginConfig['themeColorValue'] : $defaultConfig['themeColorValue']
];

$siteUrl = rtrim(Helper::options()->siteUrl, '/');

// 安全过滤输入
$mode = isset($_GET['mode']) && in_array($_GET['mode'], ['folders', 'images']) ? $_GET['mode'] : 'folders';
$currentFolder = isset($_GET['folder']) ? preg_replace('/[^a-zA-Z0-9\x{4e00}-\x{9fa5}_\-]/u', '', $_GET['folder']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = $config['perPage'];
$isApi = isset($_GET['api']) && $_GET['api'] == '1';

$baseDir = rtrim($config['scanDir'], '/') . '/';
$basePath = __TYPECHO_ROOT_DIR__ . $baseDir;

if (!is_dir($basePath)) {
    @mkdir($basePath, 0755, true);
}

// ===== 扫描函数 =====

function scanFolders($dir) {
    $folders = [];
    if (!is_dir($dir)) return $folders;

    try {
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            $path = $dir . '/' . $item;
            if (!is_dir($path)) continue;

            $realPath = realpath($path);
            if ($realPath === false || strpos($realPath, realpath($dir)) !== 0) continue;

            $images = scanImagesInFolder($path, 1);
            $imageCount = countImagesInFolder($path);

            if ($imageCount > 0) {
                $folders[] = [
                    'name' => $item,
                    'cover' => $images[0],
                    'count' => $imageCount
                ];
            }
        }
    } catch (Exception $e) {}

    usort($folders, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });

    return $folders;
}

function countImagesInFolder($dir) {
    $count = 0;
    if (!is_dir($dir)) return 0;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            $count += countImagesInFolder($path);
        } else {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'])) $count++;
        }
    }
    return $count;
}

function scanImagesInFolder($dir, $limit = 0) {
    global $siteUrl;
    $images = [];
    if (!is_dir($dir)) return $images;

    try {
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            if (is_file($path)) {
                $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'])) {
                    $relativePath = str_replace(__TYPECHO_ROOT_DIR__, '', $path);
                    if (strpos($relativePath, '/') !== 0) $relativePath = '/' . $relativePath;

                    $images[] = [
                        'url' => $siteUrl . $relativePath,
                        'width' => 0,
                        'height' => 0
                    ];

                    if ($limit > 0 && count($images) >= $limit) break;
                }
            }
        }
    } catch (Exception $e) {}

    return $images;
}

function scanAllImagesInFolder($dir, &$files = []) {
    if (!is_dir($dir)) return $files;

    try {
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;

            if (is_dir($path)) {
                scanAllImagesInFolder($path, $files);
            } else {
                $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'])) {
                    $files[] = $path;
                }
            }
        }
    } catch (Exception $e) {}

    return $files;
}

// ===== 获取数据 =====
$folders = [];
$galleryData = [];
$error = null;
$totalPages = 0;
$currentFolderTotal = 0;

if (!is_dir($basePath)) {
    $error = "目录不存在: " . htmlspecialchars($baseDir);
} else {
    if ($mode === 'folders') {
        $folders = scanFolders($basePath);
    } else {
        if (empty($currentFolder)) {
            $error = "未指定文件夹";
        } else {
            $folderPath = realpath($basePath . $currentFolder);
            $baseRealPath = realpath($basePath);

            if ($folderPath === false || strpos($folderPath, $baseRealPath) !== 0) {
                $error = "无效的文件夹路径";
            } elseif (!is_dir($folderPath)) {
                $error = "文件夹不存在";
            } else {
                $allFiles = [];
                scanAllImagesInFolder($folderPath, $allFiles);

                usort($allFiles, function($a, $b) {
                    return filemtime($b) - filemtime($a);
                });

                $currentFolderTotal = count($allFiles);
                $totalPages = ceil($currentFolderTotal / $perPage);

                $offset = ($page - 1) * $perPage;
                $pageFiles = array_slice($allFiles, $offset, $perPage);

                foreach ($pageFiles as $file) {
                    $relativePath = str_replace(__TYPECHO_ROOT_DIR__, '', $file);
                    if (strpos($relativePath, '/') !== 0) $relativePath = '/' . $relativePath;

                    $galleryData[] = [
                        'id' => md5($file),
                        'url' => $siteUrl . $relativePath
                    ];
                }
            }
        }
    }
}

// API请求
if ($isApi) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache');
    if ($mode === 'folders') {
        echo json_encode(['mode' => 'folders', 'folders' => $folders, 'error' => $error], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'mode' => 'images',
            'items' => $galleryData,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'totalFiles' => $currentFolderTotal,
            'hasMore' => $page < $totalPages,
            'error' => $error
        ], JSON_UNESCAPED_UNICODE);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>映画集 - <?php $this->title() ?></title>

    <!-- 主题色 -->
    <style>:root { --gc: <?php echo $config['themeColor']; ?>; }</style>

    <!-- 相册样式 -->
    <link rel="stylesheet" href="<?php echo $siteUrl; ?>/usr/themes/qingjian/gallery.css">

    <!-- 仅保留需要 PHP 判断的样式 -->
    <style>
        .gallery-header .title .back-link { display: <?php echo $mode === 'images' ? 'inline-flex' : 'none'; ?>; }
    </style>
</head>
<body>
    <div class="effect-indicator" id="effectIndicator">淡入淡出</div>

    <header class="gallery-header">
        <div class="title">
            <?php if ($mode === 'images'): ?>
                <a href="?" class="back-link" title="返回文件夹列表">←</a>
            <?php endif; ?>
            <span class="logo">映画集</span>
            <span class="separator">/</span>
            <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
            <?php if ($mode === 'images' && !empty($currentFolder)): ?>
                <span class="current-folder" title="<?php echo htmlspecialchars($currentFolder); ?>"><?php echo htmlspecialchars($currentFolder); ?></span>
            <?php endif; ?>
        </div>
        <div class="copyright">
            <span>© <?php echo date("Y"); ?></span>
            <a href="https://github.com/xiaomi/mimo" target="_blank" rel="noopener">MiMo</a>
        </div>
    </header>

    <?php if ($mode === 'folders'): ?>
        <div class="folder-grid" id="folderGrid">
            <?php if ($error): ?>
                <div class="error-state" style="grid-column: 1/-1;">
                    <div class="emoji-icon">⚠️</div>
                    <h3>出错了</h3>
                    <p><?php echo $error; ?></p>
                </div>
            <?php elseif (empty($folders)): ?>
                <div class="empty-state" style="grid-column: 1/-1;">
                    <div class="emoji-icon">📁</div>
                    <h3>暂无文件夹</h3>
                    <p>目录: <?php echo htmlspecialchars($baseDir); ?></p>
                    <p style="font-size:12px; margin-top:10px;">请在该目录下创建包含图片的子文件夹</p>
                </div>
            <?php else: ?>
                <?php foreach($folders as $index => $folder): ?>
                <div class="folder-card" data-folder="<?php echo htmlspecialchars($folder['name']); ?>">
                    <div class="folder-cover" style="background-image: url(<?php echo $folder['cover']['url']; ?>);"></div>
                    <div class="folder-name">
                        <span class="name"><?php echo htmlspecialchars($folder['name']); ?></span>
                        <span class="count"><?php echo $folder['count']; ?> 张</span>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="gallery-container">
            <?php if ($error): ?>
                <div class="error-state">
                    <div class="emoji-icon">⚠️</div>
                    <h3>出错了</h3>
                    <p><?php echo $error; ?></p>
                </div>
            <?php elseif (empty($galleryData)): ?>
                <div class="empty-state">
                    <div class="emoji-icon">🖼️</div>
                    <h3>暂无图片</h3>
                    <p>文件夹: <?php echo htmlspecialchars($currentFolder); ?></p>
                </div>
            <?php else: ?>
                <div class="waterfall" id="waterfall">
                    <?php foreach($galleryData as $index => $item): ?>
                    <div class="waterfall-item" data-index="<?php echo $index; ?>" data-id="<?php echo $item['id']; ?>">
                        <img src="<?php echo $item['url']; ?>" loading="lazy" onerror="this.parentElement.innerHTML='<div class=loading-placeholder>加载失败</div>'">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="infinite-trigger" id="infiniteTrigger">
                    <?php if ($page < $totalPages): ?>
                        <div class="spinner"></div><span>加载更多...</span>
                    <?php else: ?>
                        <div class="end-text">🌸 已到达映画集终点</div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- 模态框 -->
    <div class="modal" id="modal">
        <div class="modal-backdrop"></div>
        <div class="modal-bg-image" id="modalBgImage"></div>
        <div class="modal-particles" id="modalParticles"></div>
        <div class="modal-container">
            <button class="modal-btn close" id="modalClose" aria-label="关闭"></button>
            <button class="modal-btn prev" id="modalPrev" aria-label="上一张"></button>
            <button class="modal-btn next" id="modalNext" aria-label="下一张"></button>
            <div class="modal-image-wrapper">
                <img class="modal-image" id="modalImage" src="" alt="">
            </div>
            <div class="modal-counter"><span id="currentNum">1</span> / <span id="totalNum">0</span></div>
            <div class="modal-progress" id="modalProgress"></div>
            <div class="modal-shortcuts">← → 切换 | ESC 关闭</div>
        </div>
    </div>

    <script>
    (function(){
        const C={
            mode:'<?php echo $mode; ?>',
            folder:'<?php echo $currentFolder; ?>',
            color:'<?php echo $config['themeColor']; ?>',
            totalPages:<?php echo $totalPages; ?>,
            currentPage:<?php echo $page; ?>,
            hasMore:<?php echo ($page < $totalPages) ? 'true' : 'false'; ?>
        };

        let curPage=C.currentPage,loading=false,more=C.hasMore;
        let imgs=[],idx=0,changing=false;

        const effects=['fade','slide','slide-up','zoom','zoom-out','rotate','rotate-zoom','flip','flip-x','blur','blur-zoom','flash','diagonal','spiral','shrink','expand','fall','page','cube','ripple'];
        const names={fade:'淡入淡出',slide:'左右滑动','slide-up':'上下滑动',zoom:'缩放','zoom-out':'放大淡出',rotate:'旋转','rotate-zoom':'旋转缩放',flip:'3D水平翻转','flip-x':'3D垂直翻转',blur:'模糊','blur-zoom':'模糊缩放',flash:'闪烁',diagonal:'对角线',spiral:'螺旋',shrink:'收缩',expand:'膨胀',fall:'下落',page:'翻页',cube:'立方体',ripple:'波纹'};

        const $=id=>document.getElementById(id);
        const modal=$('modal'),mImg=$('modalImage'),mBg=$('modalBgImage');
        const curNum=$('currentNum'),totNum=$('totalNum'),progress=$('modalProgress');
        const particles=$('modalParticles'),indicator=$('effectIndicator');
        const waterfall=$('waterfall'),trigger=$('infiniteTrigger');

        function throttle(fn,ms){let t;return function(){if(!t){fn.apply(this,arguments);t=true;setTimeout(()=>t=false,ms)}}}
        function randEffect(){return effects[Math.floor(Math.random()*effects.length)]}

        function applyEffect(e){
            effects.forEach(x=>modal.classList.remove('effect-'+x));
            modal.classList.add('effect-'+e);
            if(indicator){indicator.textContent=names[e]||e;indicator.classList.add('show');setTimeout(()=>indicator.classList.remove('show'),1500)}
        }

        function createParticles(){
            if(!particles)return;
            particles.innerHTML='';
            for(let i=0;i<15;i++){
                const p=document.createElement('div');
                p.className='particle';
                p.style.cssText=`left:${Math.random()*100}%;animation-delay:${Math.random()*10}s;animation-duration:${10+Math.random()*15}s`;
                particles.appendChild(p);
            }
        }

        // 文件夹点击
        document.querySelectorAll('.folder-card').forEach(card=>{
            card.addEventListener('click',()=>{
                window.location.href=`?mode=images&folder=${encodeURIComponent(card.dataset.folder)}`;
            });
        });

        // 图片收集
        if(waterfall){
            document.querySelectorAll('.waterfall-item').forEach((item,i)=>{
                const img=item.querySelector('img');
                imgs.push({id:item.dataset.id,url:img.src,el:item});
                item.addEventListener('click',()=>{idx=i;openModal()});
            });
            createParticles();
            if(totNum)totNum.textContent=imgs.length;
        }

        // 无限加载
        async function loadMore(){
            if(loading||!more||C.mode!=='images')return;
            loading=true;
            if(trigger)trigger.innerHTML='<div class="spinner"></div><span>加载更多...</span>';
            try{
                const r=await fetch(`?api=1&mode=images&folder=${encodeURIComponent(C.folder)}&page=${curPage+1}`);
                const d=await r.json();
                if(d.items&&d.items.length>0){
                    const frag=document.createDocumentFragment();
                    d.items.forEach(item=>{
                        const div=document.createElement('div');
                        div.className='waterfall-item';
                        div.dataset.id=item.id;
                        div.innerHTML=`<img src="${item.url}" loading="lazy">`;
                        imgs.push({id:item.id,url:item.url,el:div});
                        div.addEventListener('click',()=>{idx=imgs.length-1;openModal()});
                        frag.appendChild(div);
                    });
                    waterfall.appendChild(frag);
                    curPage++;
                    more=d.hasMore;
                    if(totNum)totNum.textContent=imgs.length;
                    if(trigger)trigger.innerHTML=more?'<div class="spinner"></div><span>加载更多...</span>':'<div class="end-text">🌸 已到达映画集终点</div>';
                }else{
                    more=false;
                    if(trigger)trigger.innerHTML='<div class="end-text">🌸 已到达映画集终点</div>';
                }
            }catch(e){
                if(trigger){trigger.innerHTML='<span style="color:#dc3545;cursor:pointer">加载失败，点击重试</span>';trigger.addEventListener('click',loadMore,{once:true})}
            }finally{loading=false}
        }

        if(trigger&&C.mode==='images'){
            new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting&&more&&!loading)loadMore()})},{threshold:0.1,rootMargin:'200px'}).observe(trigger);
        }

        // 模态框
        function openModal(){
            if(!imgs.length)return;
            applyEffect(randEffect());
            mImg.src=imgs[idx].url;
            mBg.style.backgroundImage=`url('${imgs[idx].url}')`;
            if(curNum)curNum.textContent=idx+1;
            if(progress)progress.style.width=((idx+1)/imgs.length*100)+'%';
            modal.classList.add('active');
            document.body.style.overflow='hidden';
            mImg.classList.remove('prev-change','next-change');
        }

        function closeModal(){
            modal.classList.remove('active');
            document.body.style.overflow='';
            mImg.classList.remove('prev-change','next-change');
            changing=false;
        }

        function prevImg(){
            if(changing||!imgs.length)return;
            changing=true;
            applyEffect(randEffect());
            idx=(idx-1+imgs.length)%imgs.length;
            mImg.classList.add('prev-change');
            setTimeout(()=>{
                mImg.src=imgs[idx].url;
                mBg.style.backgroundImage=`url('${imgs[idx].url}')`;
                if(curNum)curNum.textContent=idx+1;
                if(progress)progress.style.width=((idx+1)/imgs.length*100)+'%';
                setTimeout(()=>{mImg.classList.remove('prev-change');changing=false},50);
            },200);
        }

        function nextImg(){
            if(changing||!imgs.length)return;
            changing=true;
            applyEffect(randEffect());
            idx=(idx+1)%imgs.length;
            mImg.classList.add('next-change');
            setTimeout(()=>{
                mImg.src=imgs[idx].url;
                mBg.style.backgroundImage=`url('${imgs[idx].url}')`;
                if(curNum)curNum.textContent=idx+1;
                if(progress)progress.style.width=((idx+1)/imgs.length*100)+'%';
                setTimeout(()=>{mImg.classList.remove('next-change');changing=false},50);
            },200);
        }

        const tNext=throttle(nextImg,300),tPrev=throttle(prevImg,300);

        $('modalClose').addEventListener('click',closeModal);
        $('modalPrev').addEventListener('click',tPrev);
        $('modalNext').addEventListener('click',tNext);

        modal.addEventListener('click',e=>{
            if(e.target.classList.contains('modal-backdrop')||e.target.classList.contains('modal-container'))closeModal();
        });

        document.addEventListener('keydown',e=>{
            if(!modal.classList.contains('active'))return;
            if(e.key==='Escape')closeModal();
            else if(e.key==='ArrowLeft'){e.preventDefault();tPrev()}
            else if(e.key==='ArrowRight'){e.preventDefault();tNext()}
        });

        let touchX=0;
        modal.addEventListener('touchstart',e=>{touchX=e.touches[0].clientX},{passive:true});
        modal.addEventListener('touchend',e=>{
            if(!modal.classList.contains('active')||changing)return;
            const d=touchX-e.changedTouches[0].clientX;
            if(Math.abs(d)>50){d>0?tNext():tPrev()}
        },{passive:true});
    })();
    </script>
</body>
</html>
