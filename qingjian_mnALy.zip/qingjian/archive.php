<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="content-area">
    <div class="archive-header">
        <h1 class="archive-title">
            <?php if ($this->is('category')): ?>
                分类: <?php $this->archiveTitle(); ?>
            <?php elseif ($this->is('tag')): ?>
                标签: <?php $this->archiveTitle(); ?>
            <?php elseif ($this->is('search')): ?>
                搜索: <?php $this->archiveTitle(); ?>
            <?php elseif ($this->is('author')): ?>
                作者: <?php $this->archiveTitle(); ?>
            <?php elseif ($this->is('date')): ?>
                归档: <?php $this->archiveTitle(); ?>
            <?php else: ?>
                归档
            <?php endif; ?>
        </h1>
    </div>

    <?php if ($this->have()): ?>
    <div class="post-list">
        <?php while($this->next()): ?>
        <article class="post-item">
            <h2 class="post-title">
                <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
            </h2>
            <div class="post-meta">
                <span class="meta-author"><?php $this->author->screenName(); ?></span>
                <span class="meta-sep">·</span>
                <time><?php $this->date('Y-m-d'); ?></time>
                <span class="meta-sep">·</span>
                <span class="meta-category"><?php $this->category(', '); ?></span>
                <span class="meta-sep">·</span>
                <span class="meta-views"><?php echo formatViews(getViews($this->cid)); ?> 阅读</span>
                <span class="meta-sep">·</span>
                <span><?php $this->commentsNum('0 评论', '1 评论', '%d 评论'); ?></span>
            </div>
            <div class="post-excerpt"><?php $this->excerpt(140, '...'); ?></div>
        </article>
        <?php endwhile; ?>
    </div>

    <?php $this->pageNav('« 上一页', '下一页 »'); ?>
    <?php else: ?>
        <p style="color: var(--text-muted); padding: 2rem 0;">没有找到相关文章</p>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
