<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php $fav = getThemeFavicon(); if ($fav): ?>
    <link rel="icon" href="<?php echo $fav; ?>" type="image/x-icon">
    <?php endif; ?>

    <title><?php if ($this->is('single') || $this->is('page')): ?>
<?php $this->title(); ?> - <?php $this->options->title(); ?>
<?php elseif ($this->is('category')): ?>
分类：<?php $this->archiveTitle('', '', ''); ?> - <?php $this->options->title(); ?>
<?php elseif ($this->is('tag')): ?>
标签：<?php $this->archiveTitle('', '', ''); ?> - <?php $this->options->title(); ?>
<?php elseif ($this->is('author')): ?>
作者：<?php $this->archiveTitle('', '', ''); ?> - <?php $this->options->title(); ?>
<?php elseif ($this->is('search')): ?>
搜索：<?php $this->archiveTitle('', '', ''); ?> - <?php $this->options->title(); ?>
<?php else: ?>
<?php $this->options->title(); ?>
<?php if ($this->options->subtitle): ?> - <?php $this->options->subtitle(); ?>
<?php endif; ?>
<?php endif; ?></title>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php themeColorCss(); ?>

    <?php if ($this->options->customCss): ?>
    <style><?php $this->options->customCss(); ?></style>
    <?php endif; ?>

    <?php $this->header(); ?>
</head>
<body>
<div class="site-wrapper">

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-inner">

            <div class="site-branding">
                <div class="site-avatar">
                    <?php $avatarUrl = getThemeAvatar(); ?>
                    <?php if ($avatarUrl): ?>
                        <img src="<?php echo $avatarUrl; ?>" alt="<?php $this->options->title(); ?>">
                    <?php else: ?>
                        <span><?php echo mb_substr($this->options->title(), 0, 1, 'UTF-8'); ?></span>
                    <?php endif; ?>
                </div>
                <h1 class="site-title">
                    <a href="<?php $this->options->siteUrl(); ?>">
                        <?php $logoUrl = getThemeLogo(); ?>
                        <?php if ($logoUrl): ?>
                            <img src="<?php echo $logoUrl; ?>" alt="<?php $this->options->title(); ?>" class="site-logo">
                        <?php else: ?>
                            <?php $this->options->title(); ?>
                        <?php endif; ?>
                    </a>
                </h1>
                <p class="site-description">
                    <?php if ($this->options->subtitle): ?>
                        <?php $this->options->subtitle(); ?>
                    <?php elseif ($this->options->description()): ?>
                        <?php $this->options->description(); ?>
                    <?php else: ?>
                        分享知识与思考
                    <?php endif; ?>
                </p>
            </div>

            <nav class="sidebar-nav">
                <a href="<?php $this->options->siteUrl(); ?>" class="nav-link">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    首页
                </a>
                <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                <?php while($pages->next()): ?>
                    <a href="<?php $pages->permalink(); ?>" class="nav-link">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        <?php $pages->title(); ?>
                    </a>
                <?php endwhile; ?>
            </nav>

            <div class="sidebar-search">
                <form method="post" action="<?php $this->options->siteUrl(); ?>">
                    <input type="text" name="s" placeholder="搜索文章...">
                    <button type="submit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </button>
                </form>
            </div>

            <div class="site-stats">
                <?php
                $db = \Typecho\Db::get();
                $stat = $db->fetchRow($db->select(array('COUNT(cid)' => 'total'))->from('table.contents')->where('type = ?', 'post'));
                $comments = $db->fetchRow($db->select(array('COUNT(coid)' => 'total'))->from('table.comments'));
                ?>
                <div class="stat-item">
                    <span class="stat-num"><?php echo $stat['total']; ?></span>
                    <span class="stat-label">文章</span>
                </div>
                <div class="stat-item">
                    <span class="stat-num"><?php echo $comments['total']; ?></span>
                    <span class="stat-label">评论</span>
                </div>
            </div>

            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">最新文章</h3>
                <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=5')->to($recent); ?>
                <?php while($recent->next()): ?>
                    <a href="<?php $recent->permalink(); ?>" class="recent-post-item">
                        <span class="recent-post-date"><?php $recent->date('m/d'); ?></span>
                        <?php $recent->title(); ?>
                    </a>
                <?php endwhile; ?>
            </div>

            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">分类</h3>
                <?php $this->widget('Widget_Metas_Category_List')->to($categories); ?>
                <?php while($categories->next()): ?>
                    <a href="<?php $categories->permalink(); ?>" class="category-item">
                        <span><?php $categories->name(); ?></span>
                        <span class="category-count"><?php $categories->count(); ?></span>
                    </a>
                <?php endwhile; ?>
            </div>

            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">标签</h3>
                <div class="tag-cloud">
                    <?php $this->widget('Widget_Metas_Tag_Cloud', 'limit=20&sort=mid&desc=false')->to($tags); ?>
                    <?php while($tags->next()): ?>
                        <a href="<?php $tags->permalink(); ?>" class="tag-item"><?php $tags->name(); ?></a>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </aside>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <main class="main-content">
        <header class="mobile-header">
            <button class="menu-toggle" id="menuToggle" aria-label="菜单">
                <span></span><span></span><span></span>
            </button>
            <a href="<?php $this->options->siteUrl(); ?>" class="mobile-title"><?php $this->options->title(); ?></a>
        </header>
        <div class="progress-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>

                <!-- 右上角用户栏 -->
        <div class="user-bar">
            <?php if ($this->user->hasLogin()): ?>
                <div class="user-bar-avatar" title="<?php $this->user->screenName(); ?>">
                    <?php echo mb_substr($this->user->screenName, 0, 1, 'UTF-8'); ?>
                </div>
                <div class="user-bar-dropdown">
                    <span class="user-bar-name">
                        <?php $this->user->screenName(); ?>
                        <small><?php echo $this->user->group == 'administrator' ? '管理员' : '用户'; ?></small>
                    </span>
                    <a href="<?php $this->options->adminUrl(); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
                        进入后台
                    </a>
                    <a href="<?php $this->options->adminUrl(); ?>write-post.php">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                        撰写文章
                    </a>
                    <a href="<?php echo $this->security->getTokenUrl($this->options->adminUrl('login.php?do=logout')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                        退出登录
                    </a>
                </div>
            <?php else: ?>
                <a href="<?php $this->options->adminUrl(); ?>login.php" class="user-bar-login">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    登录
                </a>
            <?php endif; ?>
        </div>
