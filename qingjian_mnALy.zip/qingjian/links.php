<?php
/**
 * 友情链接
 *
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<div class="content-area">
    <div class="archive-header">
        <h1 class="archive-title"><?php $this->title(); ?></h1>
    </div>

    <?php
    /* -------- 优先从后台"管理 → 链接"读取 -------- */
    $db = Typecho_Db::get();
    $links = array();
    try {
        $links = $db->fetchAll(
            $db->select()->from('table.metas')
            ->where('type = ?', 'link')
            ->order('`order`', Typecho_Db::SORT_ASC)
        );
    } catch (Exception $e) { /* 表不存在则忽略 */ }

    /* -------- 后台没有链接时，从页面内容解析 -------- */
    if (empty($links)) {
        $raw = $this->content;
        if (!empty($raw)) {
            $lines = explode("\n", strip_tags($raw));
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || strpos($line, '|') === false) continue;
                $parts = array_map('trim', explode('|', $line));
                if (count($parts) >= 2) {
                    $links[] = array(
                        'name'        => $parts[0],
                        'slug'        => $parts[1],
                        'description' => isset($parts[2]) ? $parts[2] : ''
                    );
                }
            }
        }
    }
    ?>

    <?php if (!empty($links)): ?>
    <div class="links-grid">
        <?php foreach ($links as $link): ?>
        <?php
            $url = $link['slug'];
            if (!filter_var($url, FILTER_VALIDATE_URL)) $url = '#';
        ?>
        <a href="<?php echo htmlspecialchars($url); ?>" class="link-card" target="_blank" rel="noopener noreferrer">
            <div class="link-avatar">
                <span><?php echo mb_substr($link['name'], 0, 1, 'UTF-8'); ?></span>
            </div>
            <div class="link-info">
                <h3 class="link-name"><?php echo htmlspecialchars($link['name']); ?></h3>
                <?php if (!empty($link['description'])): ?>
                    <p class="link-desc"><?php echo htmlspecialchars($link['description']); ?></p>
                <?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
        <p style="color: var(--text-muted); padding: 2rem 0;">
            暂无友情链接。可在后台「管理 → 链接」中添加，<br>
            或在本页面内容中按格式添加：名称 | 链接地址 | 描述
        </p>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
