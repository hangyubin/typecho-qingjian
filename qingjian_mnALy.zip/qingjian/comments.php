<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<div class="comments-section">
    <h3 class="comments-title"><?php $this->commentsNum('暂无评论', '1 条评论', '%d 条评论'); ?></h3>

    <?php $this->comments()->to($comments); ?>
    <?php while($comments->next()): ?>
        <div class="comment-item" id="<?php $comments->theId(); ?>">
            <div class="comment-header">
                <?php $comments->gravatar(36); ?>
                <div>
                    <span class="comment-author"><?php $comments->author(); ?></span>
                    <span class="comment-date"><?php $comments->date('Y-m-d H:i'); ?></span>
                </div>
            </div>
            <div class="comment-body"><?php $comments->content(); ?></div>
            <div class="comment-actions">
                <?php $comments->reply('回复'); ?>
            </div>
            <div class="comment-children">
                <?php $comments->threaded(); ?>
            </div>
        </div>
    <?php endwhile; ?>

    <?php if ($this->user->hasLogin()): ?>

        <div class="comment-respond">
            <h3>发表评论</h3>
            <form method="post" action="<?php $this->commentUrl(); ?>" class="comment-form">
                <p class="comment-logged-in">
                    以 <strong><?php $this->user->screenName(); ?></strong> 身份登录
                    <a href="<?php echo $this->security->getTokenUrl($this->options->adminUrl('login.php?do=logout')); ?>">退出</a>
                </p>
                <textarea name="text" rows="6" placeholder="写下你的评论..."><?php $this->remember('text'); ?></textarea>
                <button type="submit" class="submit-btn">提交评论</button>
            </form>
        </div>

    <?php else: ?>

        <div class="comment-login-hint">
            <p>登录后才能发表评论</p>
            <a href="<?php $this->options->adminUrl(); ?>login.php">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                去登录
            </a>
        </div>

    <?php endif; ?>
</div>
