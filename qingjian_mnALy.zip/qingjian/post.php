<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="content-area">
    <article class="post-single">

        <!-- 面包屑导航 -->
        <nav class="breadcrumb">
            <a href="<?php $this->options->siteUrl(); ?>">首页</a>
            <span class="breadcrumb-sep">›</span>
            <?php $this->category(', '); ?>
            <span class="breadcrumb-sep">›</span>
            <span class="breadcrumb-current"><?php $this->title(); ?></span>
        </nav>

        <header class="post-header">
            <h1 class="post-title"><?php $this->title(); ?></h1>
            <div class="post-meta">
                <span class="meta-author"><?php $this->author->screenName(); ?></span>
                <span class="meta-sep">·</span>
                <time><?php $this->date('Y-m-d'); ?></time>
                <span class="meta-sep">·</span>
                <span class="meta-category"><?php $this->category(', '); ?></span>
                <span class="meta-sep">·</span>
                <span class="meta-views"><?php echo formatViews(getViews($this->cid)); ?> 阅读</span>
                <span class="meta-sep">·</span>
                <span><?php $this->commentsNum('0 评论', '1 评论', '%d 评论'); ?></span>
            </div>
        </header>

        <div class="post-content">
            <?php $this->content(); ?>
        </div>

        <div class="post-tags">
            <?php $this->tags('', ' ', ''); ?>
        </div>

        <nav class="post-navigation">
            <div class="nav-prev">
                <?php $this->thePrev('上一篇: %s', ''); ?>
            </div>
            <div class="nav-next">
                <?php $this->theNext('下一篇: %s', ''); ?>
            </div>
        </nav>
    </article>

    <?php $this->need('comments.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
