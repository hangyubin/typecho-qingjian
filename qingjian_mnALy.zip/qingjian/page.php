<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="content-area">
    <?php
    $slug = $this->slug;
    $pageTitle = trim($this->title);
    $isSpecial = false;
    ?>

    <?php if ($slug === 'archive' || $pageTitle === '归档'): ?>
    <?php $isSpecial = true; ?>
    <article class="page-single">
        <header class="post-header">
            <h1 class="post-title">归档</h1>
            <div class="post-meta">
                <?php
                $db = Typecho_Db::get();
                $total = $db->fetchRow(
                    $db->select(array('COUNT(cid)' => 'total'))
                        ->from('table.contents')
                        ->where('type = ?', 'post')
                        ->where('status = ?', 'publish')
                );
                ?>
                <span>共 <?php echo $total['total']; ?> 篇文章</span>
            </div>
        </header>
        <div class="archive-timeline">
            <?php
            $posts = $db->fetchAll(
                $db->select('cid', 'title', 'slug', 'created')
                    ->from('table.contents')
                    ->where('type = ?', 'post')
                    ->where('status = ?', 'publish')
                    ->order('created', Typecho_Db::SORT_DESC)
            );

            if (count($posts) > 0):
                $currentYear = '';
                foreach ($posts as $post):
                    $year = date('Y', $post['created']);
                    $monthDay = date('m-d', $post['created']);
                    $permalink = Typecho_Router::url('post', $post, $this->options->index);

                    if ($year !== $currentYear):
                        $currentYear = $year;
            ?>
                <h2 class="archive-year"><?php echo $year; ?></h2>
            <?php endif; ?>
                <div class="archive-item">
                    <span class="archive-date"><?php echo $monthDay; ?></span>
                    <a href="<?php echo $permalink; ?>" class="archive-title"><?php echo htmlspecialchars($post['title']); ?></a>
                </div>
            <?php
                endforeach;
            else:
            ?>
                <p style="color: var(--text-muted); padding: 2rem 0;">暂无文章</p>
            <?php endif; ?>
        </div>
    </article>

    <?php elseif ($pageTitle === '标签云' || $pageTitle === '标签'): ?>
    <?php $isSpecial = true; ?>
    <article class="page-single">
        <header class="post-header">
            <h1 class="post-title">标签云</h1>
        </header>
        <div class="page-tags-cloud">
            <?php $this->widget('Widget_Metas_Tag_Cloud', 'limit=0&sort=mid&desc=false')->to($tags); ?>
            <?php while($tags->next()): ?>
                <a href="<?php $tags->permalink(); ?>" class="page-tag-item">
                    <?php $tags->name(); ?>
                    <sup><?php $tags->count(); ?></sup>
                </a>
            <?php endwhile; ?>
        </div>
    </article>

    <?php else: ?>
    <article class="page-single">
        <header class="post-header">
            <h1 class="post-title"><?php $this->title(); ?></h1>
        </header>
        <div class="post-content">
            <?php $this->content(); ?>
        </div>
    </article>
    <?php endif; ?>

    <?php if (!$isSpecial): ?>
        <?php $this->need('comments.php'); ?>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
